/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javalab;
import java.util.Scanner;
/**
 *
 * @author estudiante
 */
public class JavaLab {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double M;
        double C;
        double R;
        Scanner a1 = new Scanner (System.in);
        System.out.println("coloca cantidad M");
        M=a1.nextInt();
        Scanner gerson1 = new Scanner (System.in);
        System.out.println("colcoa cantidad C");
        C=gerson1.nextInt();
        R=M+C/2;
        System.out.println("R es igual a "+""+R);
    }
    
}
